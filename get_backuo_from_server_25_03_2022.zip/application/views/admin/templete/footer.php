
<footer class="bdT ta-c p-30 lh-0 fsz-sm c-grey-600"><span>Copyright © 2022 Designed by <a href="https://thinksurfmedia.com/" target="_blank" title="Colorlib">Thinksurf Media</a>. All rights reserved.</span>
    <!-- <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script> -->
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-23581568-13');

    </script>
</footer>
<script type="text/javascript" src="<?php echo base_url('assest/js/vendor.js')?>"></script>
<script type="text/javascript" src=" <?php echo base_url('assest/js/bundle.js') ?> "></script>
</body>

</html>
